import 'package:flutter/material.dart';

class EditProfilePage extends StatelessWidget {
  final String name;
  final String surname;
  final String phone;
  final String email;
  final String role;
  final String language;

  EditProfilePage({
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
  });

  @override
  Widget build(BuildContext context) {
    final nameCtrl = TextEditingController(text: name);
    final surnameCtrl = TextEditingController(text: surname);
    final phoneCtrl = TextEditingController(text: phone);
    final emailCtrl = TextEditingController(text: email);
    final roleCtrl = TextEditingController(text: role);
    final langCtrl = TextEditingController(text: language);

    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: "Name")),
            TextField(controller: surnameCtrl, decoration: const InputDecoration(labelText: "Surname")),
            TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: "Phone")),
            TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: "Email")),
            TextField(controller: roleCtrl, decoration: const InputDecoration(labelText: "Role")),
            TextField(controller: langCtrl, decoration: const InputDecoration(labelText: "Programming Language")),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, {
                  'name': nameCtrl.text,
                  'surname': surnameCtrl.text,
                  'phone': phoneCtrl.text,
                  'email': emailCtrl.text,
                  'role': roleCtrl.text,
                  'language': langCtrl.text,
                });
              },
              child: const Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
