import '../model/profile_model.dart';

class ProfileViewModel {
  Profile profile = Profile(
    name: "Bongani",
    surname: "Metsing",
    phone: "0737368867",
    email: "bonganimetsing22@gmail.com",
    role: "Software Analyst",
    language: "C# Dart",
  );

  void updateProfile(Profile updatedProfile) {
    profile = updatedProfile;
  }
}
