import 'package:flutter/material.dart';
import 'edit_profile_page.dart';

class ProfilePage extends StatefulWidget {
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String name = "Bongani";
  String surname = "Metsing";
  String phone = "0737368867";
  String email = "bonganimetsing22@gmail.com";
  String role = "Software Analyst";
  String language = "C# Dart";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Profile")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 55,
              backgroundImage: const AssetImage('assets/bongs.jpeg'),
            ),
            const SizedBox(height: 20),
            Text("$name $surname", style: const TextStyle(fontSize: 22)),
            Text(phone),
            Text(email),
            Text(role),
            Text(language),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditProfilePage(
                      name: name,
                      surname: surname,
                      phone: phone,
                      email: email,
                      role: role,
                      language: language,
                    ),
                  ),
                );

                if (result != null) {
                  setState(() {
                    name = result['name'];
                    surname = result['surname'];
                    phone = result['phone'];
                    email = result['email'];
                    role = result['role'];
                    language = result['language'];
                  });
                }
              },
              child: const Text("Edit Profile"),
            )
          ],
        ),
      ),
    );
  }
}
